#include "SystemPage.h"



SystemPage::SystemPage()
{
}


SystemPage::~SystemPage()
{
}

string SystemPage::getPagePath()
{
	return pagePath;
}

string SystemPage::runPage(PageRequest request)
{
	return string();
}
