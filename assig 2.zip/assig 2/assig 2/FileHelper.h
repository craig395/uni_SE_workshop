#pragma once
#include <string>

using namespace std;

class FileHelper
{
public:
	FileHelper();
	~FileHelper();
	string getTextfromFile(string file);
};

