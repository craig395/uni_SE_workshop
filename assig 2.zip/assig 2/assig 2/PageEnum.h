#pragma once

enum pageId
{
	indexID,
	orderID,
	tableID,
	findTableID,
	openTabID,
	closeTabID,
	takeOrderID,
	makePaymentID,
	setTableStatusID,
	styleSheetID,
	unknown404
};